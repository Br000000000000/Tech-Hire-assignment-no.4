"""
Management command: seed_data

Creates two test users and 15 sample job postings.

Usage:
    python manage.py seed_data

Users created:
    basic_user   / password: Pass1234!   →  Basic tier
    premium_user / password: Pass1234!   →  Premium tier
    admin        / password: admin123    →  Django superuser (Premium tier)
"""
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from jobs.models import UserProfile, JobPosting


JOBS = [
    {
        "title": "Registered Nurse – ICU",
        "description": (
            "Provide critical care to patients in our intensive care unit. "
        ),
        "location": "Carigara",
        "company_name": "Memorial Hospital",
        "salary_range": "$75,000 – $95,000",
        "application_link": "https://nm.org/careers/registered-nurse-icu",
    },
    {
        "title": "Elementary School Teacher",
        "description": (
            "Educate and inspire students in grades 3–5."
            "teaching license required."
        ),
        "location": "Austin",
        "company_name": "Independent School District",
        "salary_range": "$48,000 – $62,000",
        "application_link": "https://austinisd.org/careers/elementary-teacher",
    },
    {
        "title": "Licensed Electrician",
        "description": (
            "Install, maintain, and repair electrical systems in residential and "
            "commercial properties."
        ),
        "location": "Houston, TX",
        "company_name": "Brighter Power Solutions",
        "salary_range": "$58,000 – $80,000",
        "application_link": "https://brighterpowersolutions.com/jobs/electrician",
    },
    {
        "title": "Physical Therapist",
        "description": (
            "Assess and treat patients recovering from injuries, surgeries, or chronic "
            "conditions."
            "and state licensure required."
        ),
        "location": "Phoenix, AZ",
        "company_name": "Banner Health",
        "salary_range": "$80,000 – $100,000",
        "application_link": "https://bannerhealth.com/careers/physical-therapist",
    },
    {
        "title": "Sous Chef",
        "description": (
            "Support the Head Chef in running a busy restaurant kitchen."
            "and culinary training preferred."
        ),
        "location": "New York, NY",
        "company_name": "The Garden Table Restaurant",
        "salary_range": "$55,000 – $72,000",
        "application_link": "https://gardentable.com/careers/sous-chef",
    },
    {
        "title": "Police Officer",
        "description": (
            "Patrol assigned districts, respond to emergency calls, conduct investigations, "
            "and enforce local ordinances. Build positive community relationships and "
            "uphold public safety. Must pass physical fitness, written, and psychological "
            "exams. Academy training provided for qualified candidates."
        ),
        "location": "Denver, CO",
        "company_name": "Denver Police Department",
        "salary_range": "$60,000 – $85,000",
        "application_link": "https://denvergov.org/careers/police-officer",
    },
    {
        "title": "Plumber",
        "description": (
            "Install and repair pipes, fixtures, and plumbing systems for residential "
            "and commercial clients. Diagnose issues, interpret blueprints, and ensure "
            "compliance with building codes. Valid plumbing license and 2+ years "
            "experience required."
        ),
        "location": "Seattle, WA",
        "company_name": "ClearFlow Plumbing",
        "salary_range": "$55,000 – $78,000",
        "application_link": "https://clearflowplumbing.com/jobs/plumber",
    },
    {
        "title": "Accountant",
        "description": (
            "Prepare and review financial statements, manage accounts payable and "
            "receivable, and ensure tax compliance. Work closely with management to "
            "support budgeting and financial planning. CPA certification preferred; "
            "Bachelor's degree in Accounting required."
        ),
        "location": "Dallas, TX",
        "company_name": "Meridian Financial Group",
        "salary_range": "$60,000 – $80,000",
        "application_link": "https://meridianfinancial.com/careers/accountant",
    },
    {
        "title": "Dental Hygienist",
        "description": (
            "Perform teeth cleanings, take X-rays, and educate patients on oral hygiene "
            "best practices. Assist dentists during examinations and document patient "
            "records accurately. Associate's or Bachelor's degree in Dental Hygiene and "
            "state license required."
        ),
        "location": "San Diego, CA",
        "company_name": "Bright Smile Dental Clinic",
        "salary_range": "$70,000 – $90,000",
        "application_link": "https://brightsmile.com/careers/dental-hygienist",
    },
    {
        "title": "Social Worker",
        "description": (
            "Provide case management, counseling, and community resources to individuals "
            "and families in need. Conduct assessments, develop care plans, and advocate "
            "for clients' wellbeing. Master's in Social Work (MSW) and licensure (LCSW) "
            "strongly preferred."
        ),
        "location": "Baltimore, MD",
        "company_name": "Harbor Community Services",
        "salary_range": "$48,000 – $65,000",
        "application_link": "https://harborcs.org/careers/social-worker",
    },
    {
        "title": "HVAC Technician",
        "description": (
            "Install, service, and repair heating, ventilation, and air conditioning "
            "systems in residential and commercial buildings. Diagnose mechanical faults "
            "and perform preventive maintenance. EPA 608 certification and 2+ years of "
            "field experience required."
        ),
        "location": "Las Vegas, NV",
        "company_name": "Desert Air HVAC Services",
        "salary_range": "$52,000 – $72,000",
        "application_link": "https://desertairhvac.com/jobs/hvac-technician",
    },
    {
        "title": "Paramedic",
        "description": (
            "Respond to emergency calls, assess patient conditions, administer pre-hospital "
            "care, and transport patients to medical facilities. Work as part of a two-person "
            "crew and communicate with hospital staff. Current National Registry Paramedic "
            "(NRP) certification required."
        ),
        "location": "Miami, FL",
        "company_name": "Miami-Dade Fire Rescue",
        "salary_range": "$50,000 – $70,000",
        "application_link": "https://miamidade.gov/fire/careers/paramedic",
    },
    {
        "title": "High School Counselor",
        "description": (
            "Guide students through academic planning, college applications, and personal "
            "development. Provide individual and group counseling, coordinate with parents "
            "and teachers, and support students in crisis. Master's degree in School "
            "Counseling and valid state license required."
        ),
        "location": "Atlanta, GA",
        "company_name": "Atlanta Public Schools",
        "salary_range": "$52,000 – $68,000",
        "application_link": "https://atlantapublicschools.us/careers/hs-counselor",
    },
    {
        "title": "Pharmacist",
        "description": (
            "Dispense prescription medications, counsel patients on drug interactions "
            "and side effects, and collaborate with healthcare providers. Manage pharmacy "
            "inventory and ensure regulatory compliance. PharmD degree and active state "
            "pharmacist license required."
        ),
        "location": "Boston, MA",
        "company_name": "Wellness Care Pharmacy",
        "salary_range": "$115,000 – $140,000",
        "application_link": "https://wellnesscarepharmacy.com/careers/pharmacist",
    },
    {
        "title": "Construction Project Manager",
        "description": (
            "Oversee residential and commercial construction projects from planning through "
            "completion. Coordinate subcontractors, manage budgets and timelines, and ensure "
            "compliance with safety regulations. Bachelor's degree in Construction Management "
            "or Civil Engineering and 5+ years of experience required."
        ),
        "location": "Nashville, TN",
        "company_name": "Keystone Builders Group",
        "salary_range": "$85,000 – $115,000",
        "application_link": "https://keystonebuilders.com/careers/project-manager",
    },
]


class Command(BaseCommand):
    help = "Seed the database with demo users and job postings."

    def handle(self, *args, **kwargs):
        self.stdout.write("🌱  Seeding TechHire database…\n")

        # ── Superuser ─────────────────────────────────────────────────────────
        if not User.objects.filter(username="admin").exists():
            User.objects.create_superuser("admin", "admin@techhire.dev", "admin123")
            self.stdout.write(self.style.SUCCESS("  ✔  Created superuser: admin / admin123"))
        else:
            self.stdout.write("  –  Superuser 'admin' already exists, skipping.")

        # FIX: ensure admin always has a Premium UserProfile
        admin_user = User.objects.get(username="admin")
        UserProfile.objects.update_or_create(
            user=admin_user,
            defaults={"membership_tier": "premium"},
        )
        self.stdout.write(self.style.SUCCESS("  ✔  Ensured admin UserProfile (premium)"))

        # ── Basic user ────────────────────────────────────────────────────────
        basic_user, created = User.objects.get_or_create(username="basic_user")
        if created:
            basic_user.set_password("Pass1234!")
            basic_user.email = "basic@techhire.dev"
            basic_user.save()
            self.stdout.write(self.style.SUCCESS("  ✔  Created user: basic_user / Pass1234!"))
        UserProfile.objects.get_or_create(user=basic_user, defaults={"membership_tier": "basic"})

        # ── Premium user ──────────────────────────────────────────────────────
        premium_user, created = User.objects.get_or_create(username="premium_user")
        if created:
            premium_user.set_password("Pass1234!")
            premium_user.email = "premium@techhire.dev"
            premium_user.save()
            self.stdout.write(self.style.SUCCESS("  ✔  Created user: premium_user / Pass1234!"))
        UserProfile.objects.update_or_create(
            user=premium_user,
            defaults={"membership_tier": "premium"},
        )

        # ── Job postings ──────────────────────────────────────────────────────
        created_count = 0
        for job_data in JOBS:
            _, created = JobPosting.objects.get_or_create(
                title=job_data["title"],
                defaults=job_data,
            )
            if created:
                created_count += 1

        self.stdout.write(
            self.style.SUCCESS(f"  ✔  Created {created_count} job posting(s) ({len(JOBS) - created_count} already existed).")
        )
        self.stdout.write(self.style.SUCCESS("\n✅  Seed complete!\n"))
        self.stdout.write("  Login credentials:")
        self.stdout.write("    admin        / admin123   (Django admin, Premium tier)")
        self.stdout.write("    basic_user   / Pass1234!  (Basic tier)")
        self.stdout.write("    premium_user / Pass1234!  (Premium tier)\n")